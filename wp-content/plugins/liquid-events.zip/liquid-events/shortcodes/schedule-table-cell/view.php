<?php

extract( $atts );

// classes
$classes = array( 
	'liquid-st-cell',
		
	$el_class, 
	$this->get_id() 
);

?>

<div id="<?php echo $this->get_id(); ?>" class="<?php echo $this->sanitize_html_classes( $classes ) ?>" <?php $this->get_opts() ?>></div>