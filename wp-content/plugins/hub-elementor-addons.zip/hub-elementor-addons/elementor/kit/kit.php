<?php 

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

include_once LD_ELEMENTOR_PATH . 'elementor/kit/tabs/woocommerce.php';
