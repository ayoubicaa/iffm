<?php
 if ( $element_name === 'ld_slideshow_2' ) {

    $widget_utils['lqdsep-utils-flex-d'] = array();
    $widget_utils['lqdsep-utils-flex-inline-d'] = array();
    $widget_utils['lqdsep-utils-flex-column'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-center'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-end'] = array();
    $widget_utils['lqdsep-utils-flex-justify-content-center'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-h-100'] = array();
    $widget_utils['lqdsep-utils-p-4'] = array();
    $widget_utils['lqdsep-utils-pt-3'] = array();
    $widget_utils['lqdsep-utils-ps-3'] = array();
    $widget_utils['lqdsep-utils-pe-3'] = array();
    $widget_utils['lqdsep-utils-m-0'] = array();
    $widget_utils['lqdsep-utils-border-radius-6'] = array();
    $widget_utils['lqdsep-utils-border-radius-circle'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-pos-abs'] = array();
    $widget_utils['lqdsep-utils-pos-fix'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-zindex-0'] = array();
    $widget_utils['lqdsep-utils-zindex-2'] = array();
    $widget_utils['lqdsep-utils-zindex-3'] = array();
    $widget_utils['lqdsep-utils-reset-ul'] = array();
    $widget_utils['lqdsep-utils-text-vertical'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();
    $widget_utils['lqdsep-utils-objfit-cover'] = array();
    $widget_utils['lqdsep-utils-objfit-center'] = array();
    $widget_utils['lqdsep-utils-pointer-events-none'] = array();

};