<?php
 if ( $element_name === 'ld_throwable' ) {

		$widget_utils['lqdsep-utils-block-inline-d'] = array();
		$widget_utils['lqdsep-utils-m-0'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-pos-abs'] = array();
    $widget_utils['lqdsep-utils-pos-tl'] = array();
    $widget_utils['lqdsep-utils-text-ws-nowrap'] = array();
    $widget_utils['lqdsep-utils-pointer-events-none'] = array();
    $widget_utils['lqdsep-utils-pointer-events-auto'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();
    $widget_utils['lqdsep-utils-user-select-none'] = array();

};