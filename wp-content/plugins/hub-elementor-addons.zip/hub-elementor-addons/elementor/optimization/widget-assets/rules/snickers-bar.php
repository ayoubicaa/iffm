<?php

if (
  $element_name === 'ld_woo_products' ||
  $element_name === 'ld_woo_products_list'
) {
  
  $widget_utils['lqdsep-utils-flex-d'] = array();
  $widget_utils['lqdsep-utils-flex-wrap'] = array();
  $widget_utils['lqdsep-utils-flex-align-items-center'] = array();
  $widget_utils['lqdsep-utils-mt-0'] = array();
  $widget_utils['lqdsep-utils-mb-0'] = array();
  $widget_utils['lqdsep-utils-ms-4'] = array();

}