<?php
 if ( $element_name === 'ld_milestone' ) {

    $widget_utils['lqdsep-utils-flex-d'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-start'] = array();
    $widget_utils['lqdsep-utils-flex-grow-1'] = array();
    $widget_utils['lqdsep-utils-mt-0'] = array();
    $widget_utils['lqdsep-utils-me-3'] = array();
    $widget_utils['lqdsep-utils-text-uppercase'] = array();
    $widget_utils['lqdsep-utils-text-weight-bold'] = array();
    $widget_utils['lqdsep-utils-text-center'] = array();

};