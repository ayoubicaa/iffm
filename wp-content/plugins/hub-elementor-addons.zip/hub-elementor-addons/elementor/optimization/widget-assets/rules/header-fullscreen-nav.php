<?php
if ( $element_name === 'ld_fullscreen_nav' ) {

   $widget_utils['lqdsep-utils-flex-d'] = array();
   $widget_utils['lqdsep-utils-flex-column'] = array();
   $widget_utils['lqdsep-utils-flex-justify-content-end'] = array();
   $widget_utils['lqdsep-utils-flex-grow-1'] = array();
   $widget_utils['lqdsep-utils-w-100'] = array();
   $widget_utils['lqdsep-utils-h-100'] = array();
   $widget_utils['lqdsep-utils-h-vh-100'] = array();
   $widget_utils['lqdsep-utils-p-0'] = array();
   $widget_utils['lqdsep-utils-m-0'] = array();
   $widget_utils['lqdsep-utils-pos-rel'] = array();
   $widget_utils['lqdsep-utils-pos-fix'] = array();
   $widget_utils['lqdsep-utils-pos-tl'] = array();
   $widget_utils['lqdsep-utils-overflow-hidden'] = array();

};