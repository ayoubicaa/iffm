<?php
if ( $element_name === 'ld_header_dropdown' ) {
  
  $widget_utils['lqdsep-utils-flex-d'] = array();
  $widget_utils['lqdsep-utils-pos-rel'] = array();
  $widget_utils['lqdsep-utils-pos-abs'] = array();
  
};