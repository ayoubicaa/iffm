<?php
 if ( $element_name === 'ld_icon_box_circle' ) {

    $widget_utils['lqdsep-utils-flex-d'] = array();
    $widget_utils['lqdsep-utils-flex-inline-d'] = array();
    $widget_utils['lqdsep-utils-flex-column'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-center'] = array();
    $widget_utils['lqdsep-utils-flex-justify-content-center'] = array();
    $widget_utils['lqdsep-utils-h-pt-100'] = array();
    $widget_utils['lqdsep-utils-border-radius-circle'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-pos-abs'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-text-center'] = array();
    $widget_utils['lqdsep-utils-transform-perspective'] = array();
    $widget_utils['lqdsep-utils-transform-style-3d'] = array();

};