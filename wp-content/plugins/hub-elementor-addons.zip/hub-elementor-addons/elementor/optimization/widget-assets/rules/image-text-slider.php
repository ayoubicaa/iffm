<?php
 if ( $element_name === 'ld_imgtxt_slider' ) {

    $widget_utils['lqdsep-utils-flex-inline-d'] = array();
    $widget_utils['lqdsep-utils-block-d'] = array();
    $widget_utils['lqdsep-utils-flex-column'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-center'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-zindex-1'] = array();
    $widget_utils['lqdsep-utils-zindex-2'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-text-center'] = array();
    $widget_utils['lqdsep-utils-pointer-events-none'] = array();

};