<?php
 if ( $element_name === 'ld_section_flow' ) {

    $widget_utils['lqdsep-utils-flex-wrap'] = array();
    $widget_utils['lqdsep-utils-flex-align-items-start'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-h-vh-100'] = array();
    $widget_utils['lqdsep-utils-ps-0'] = array();
    $widget_utils['lqdsep-utils-pe-0'] = array();
    $widget_utils['lqdsep-utils-me-0'] = array();
    $widget_utils['lqdsep-utils-ms-0'] = array();
    $widget_utils['lqdsep-utils-pos-abs'] = array();
    $widget_utils['lqdsep-utils-pos-sticky'] = array();
    $widget_utils['lqdsep-utils-pos-tl'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();

};