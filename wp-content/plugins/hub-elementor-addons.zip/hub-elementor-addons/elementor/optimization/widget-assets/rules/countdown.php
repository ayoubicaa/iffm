<?php
 // Fancy box utils
 if ( $element_name === 'ld_countdown' ) {

    $widget_utils['lqdsep-utils-mt-0'] = array();
    $widget_utils['lqdsep-utils-mb-0'] = array();

};