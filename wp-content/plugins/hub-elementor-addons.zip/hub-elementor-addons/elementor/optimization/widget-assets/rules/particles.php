<?php
 if ( $element_name === 'ld_particles' ) {

    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-pointer-events-none'] = array();

};