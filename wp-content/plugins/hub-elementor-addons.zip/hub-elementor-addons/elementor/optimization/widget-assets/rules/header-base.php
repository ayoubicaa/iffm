<?php
$header_files = array(
    // 'lqdsep-header-base' => array(),
    // 'lqdsep-header-nav-trigger-base' => array(),
    // 'lqdsep-header-mobile-menu-base' => array(),
);

// for mobile nav trigger
// $widget_utils['lqdsep-utils-flex-d'] = array();
// $widget_utils['lqdsep-utils-flex-column'] = array();
// $widget_utils['lqdsep-utils-flex-align-items-center'] = array();
// $widget_utils['lqdsep-utils-flex-justify-content-center'] = array();
// $widget_utils['lqdsep-utils-block-inline-d'] = array();
// $widget_utils['lqdsep-utils-w-100'] = array();
// $widget_utils['lqdsep-utils-h-100'] = array();
// $widget_utils['lqdsep-utils-pos-rel'] = array();
// $widget_utils['lqdsep-utils-zindex-1'] = array();