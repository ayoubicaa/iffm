<?php
 if ( $element_name === 'ld_masked_image' ) {

    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();

};