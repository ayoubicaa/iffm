<?php
 if ( $element_name === 'ld_text_reveal' ) {

    $widget_utils['lqdsep-utils-mt-0'] = array();
    $widget_utils['lqdsep-utils-mb-0'] = array();

};