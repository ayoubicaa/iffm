<?php
if ( $element_name === 'ld_header_separator' ) {

   $widget_utils['lqdsep-utils-flex-d'] = array();
   $widget_utils['lqdsep-utils-flex-grow-1'] = array();

};