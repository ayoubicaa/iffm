<?php
 if (
    $element_name === 'ld_carousel_stack' ||
    $element_name === 'ld_testimonial_carousel_stack'
) {

    $widget_utils['lqdsep-utils-flex-d'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-h-100'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();

};