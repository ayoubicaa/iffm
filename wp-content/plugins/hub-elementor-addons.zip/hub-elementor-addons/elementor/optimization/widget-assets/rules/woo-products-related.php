<?php
 if ( $element_name === 'ld_woo_product_related' ) {

  $widget_utils['lqdsep-utils-mt-0'] = array();
  $widget_utils['lqdsep-utils-mb-0'] = array();
  $widget_utils['lqdsep-utils-pos-rel'] = array();
  $widget_utils['lqdsep-utils-overlay'] = array();

};