<?php
 if ( $element_name === 'ld_woo_product_sharing' ) {

    $widget_utils['lqdsep-utils-me-3'] = array();
    $widget_utils['lqdsep-utils-reset-ul'] = array();
    $widget_utils['lqdsep-utils-inline-ul'] = array();

};