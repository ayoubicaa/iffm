<?php
 if ( $element_name === 'ld_images_comparison' ) {

    $widget_utils['lqdsep-utils-block-d'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-mb-0'] = array();
    $widget_utils['lqdsep-utils-border-radius-4'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-pos-abs'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();
    $widget_utils['lqdsep-utils-backface-hidden'] = array();

};