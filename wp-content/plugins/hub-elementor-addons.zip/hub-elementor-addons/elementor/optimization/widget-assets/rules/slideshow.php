<?php
 if ( $element_name === 'ld_slideshow' ) {

    $widget_utils['lqdsep-utils-flex-d'] = array();
    $widget_utils['lqdsep-utils-flex-column'] = array();
    $widget_utils['lqdsep-utils-flex-justify-content-center'] = array();
    $widget_utils['lqdsep-utils-flex-justify-content-end'] = array();
    $widget_utils['lqdsep-utils-w-100'] = array();
    $widget_utils['lqdsep-utils-h-100'] = array();
    $widget_utils['lqdsep-utils-h-pt-150'] = array();
    $widget_utils['lqdsep-utils-pt-2'] = array();
    $widget_utils['lqdsep-utils-pt-4'] = array();
    $widget_utils['lqdsep-utils-pb-2'] = array();
    $widget_utils['lqdsep-utils-pb-4'] = array();
    $widget_utils['lqdsep-utils-ps-3'] = array();
    $widget_utils['lqdsep-utils-pe-3'] = array();
    $widget_utils['lqdsep-utils-m-0'] = array();
    $widget_utils['lqdsep-utils-mt-3'] = array();
    $widget_utils['lqdsep-utils-pos-rel'] = array();
    $widget_utils['lqdsep-utils-zindex-2'] = array();
    $widget_utils['lqdsep-utils-overlay'] = array();
    $widget_utils['lqdsep-utils-overflow-hidden'] = array();
    $widget_utils['lqdsep-utils-objfit-cover'] = array();
    $widget_utils['lqdsep-utils-objfit-center'] = array();
    
};