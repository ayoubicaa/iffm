<?php

$block_reveal = array(
  'lqdsep-block-reveal-base' => 'elements/block-reveal/block-reveal-base.css',
);