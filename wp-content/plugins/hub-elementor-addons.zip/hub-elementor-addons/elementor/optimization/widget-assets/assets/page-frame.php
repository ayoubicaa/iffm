<?php
$page_frame = array(
  'lqdsep-page-frame-base' => 'theme-features/page-frame.css',
);