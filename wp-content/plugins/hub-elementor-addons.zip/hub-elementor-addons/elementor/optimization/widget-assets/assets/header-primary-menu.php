<?php
 $header_primary_menu = array(
    'lqdsep-header-primary-menu-base' => 'header/modules/module-primary-menu.css',
    'lqdsep-header-megamenu-base' => 'header/megamenu/megamenu-base.css',
    'lqdsep-header-submenu-base' => 'header/submenu/submenu-base.css',
    'lqdsep-header-submenu-style-cover' => 'header/submenu/submenu-style-cover.css',
    'lqdsep-header-nav-hover-style-fade' => 'header/nav/nav-hover-style-fade.css',
    'lqdsep-header-nav-hover-style-fill' => 'header/nav/nav-hover-style-fill.css',
    'lqdsep-header-nav-visible-ontoggle' => 'header/nav/nav-visible-ontoggle.css',
);