<?php
 $google_map = array(
    'lqdsep-google-map-info-box' => 'elements/google-map/google-map-info-box.css',
    'lqdsep-google-map-custom-marker' => 'elements/google-map/google-map-custom-marker.css',
);