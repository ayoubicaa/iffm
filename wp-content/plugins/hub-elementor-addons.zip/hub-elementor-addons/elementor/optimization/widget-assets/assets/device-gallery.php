<?php
 $device_gallery = array(
    'lqdsep-device-gallery-base' => 'elements/device-gallery/device-gallery-base.css',
    'lqdsep-device-gallery-laptop-base' => 'elements/device-gallery/device-gallery-laptop-base.css',
    'lqdsep-device-gallery-mobile-base' => 'elements/device-gallery/device-gallery-mobile-base.css',
    'lqdsep-device-gallery-mobile-shadow-float' => 'elements/device-gallery/device-gallery-mobile-shadow-float.css',
    'lqdsep-device-gallery-mobile-shadow-long' => 'elements/device-gallery/device-gallery-mobile-shadow-long.css',
    'lqdsep-device-gallery-mobile-shadow-medium' => 'elements/device-gallery/device-gallery-mobile-shadow-medium.css',
    'lqdsep-device-gallery-mobile-shadow-stand' => 'elements/device-gallery/device-gallery-mobile-shadow-stand.css',
);