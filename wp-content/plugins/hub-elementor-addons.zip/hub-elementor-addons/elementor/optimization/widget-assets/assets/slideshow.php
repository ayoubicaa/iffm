<?php
 $slideshow = array(
    'lqdsep-slideshow-base' => 'elements/slideshow/slideshow-base.css',
);