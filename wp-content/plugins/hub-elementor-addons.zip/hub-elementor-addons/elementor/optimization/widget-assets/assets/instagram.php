<?php
 $instagram_feed = array(
    'lqdsep-instagram-feed-base' => 'elements/instagram-feed/instagram-feed-base.css',
);