<?php
 $header_scroll_indicator = array(
    'lqdsep-header-scroll-indicator-base' => 'header/modules/module-scroll-indicator.css',
    'lqdsep-header-scroll-indicator-dot' => 'header/modules/module-scroll-indicator-dot.css',
);