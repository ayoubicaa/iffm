<?php
 $fullscreen_project = array(
    'lqdsep-fullscreen-project-base' => 'elements/fullscreen-project/fullscreen-project-base.css',
);