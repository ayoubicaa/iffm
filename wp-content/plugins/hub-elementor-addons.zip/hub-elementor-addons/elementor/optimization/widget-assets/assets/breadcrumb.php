<?php
$breadcrumb = array(
  'lqdsep-breadcrumb-base' => 'elements/breadcrumb/breadcrumb-base.css',
);