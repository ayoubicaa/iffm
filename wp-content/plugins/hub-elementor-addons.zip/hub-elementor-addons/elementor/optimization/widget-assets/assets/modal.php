<?php

$modal = array(
  'lqdsep-modal-base' => 'elements/modal/modal-base.css',
  'lqdsep-modal-type-box' => 'elements/modal/modal-type-box.css',
  'lqdsep-modal-type-default' => 'elements/modal/modal-type-default.css',
  'lqdsep-modal-type-fullscreen' => 'elements/modal/modal-type-fullscreen.css',
);