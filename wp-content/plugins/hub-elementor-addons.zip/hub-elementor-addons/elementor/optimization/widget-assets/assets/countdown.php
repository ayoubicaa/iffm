<?php
 $countdown = array(
    'lqdsep-countdown-base' => 'elements/countdown/countdown-base.css',
    'lqdsep-countdown-inline' => 'elements/countdown/countdown-inline.css',
);