<?php
 $custom_list = array(
    'lqdsep-bullet-list-base' => 'elements/bullet-list/bullet-list-base.css',
    'lqdsep-bullet-list-inline' => 'elements/bullet-list/bullet-list-inline.css',
);