<?php

$filter_list = array(
  'lqdsep-filter-list-base' => 'elements/filter-list/filter-list-base.css',
  'lqdsep-filter-list-counter' => 'elements/filter-list/filter-list-counter.css',
  'lqdsep-filter-list-decorated' => 'elements/filter-list/filter-list-decorated.css',
  'lqdsep-filter-list-inline' => 'elements/filter-list/filter-list-inline.css',
  'lqdsep-filter-list-lg' => 'elements/filter-list/filter-list-lg.css',
  'lqdsep-filter-list-line-through' => 'elements/filter-list/filter-list-line-through.css',
  'lqdsep-filter-list-md' => 'elements/filter-list/filter-list-md.css',
  'lqdsep-filter-list-scheme-light' => 'elements/filter-list/filter-list-scheme-light.css',
  'lqdsep-filter-list-sm' => 'elements/filter-list/filter-list-sm.css',
  'lqdsep-filter-list-style-1' => 'elements/filter-list/filter-list-style-1.css',
  'lqdsep-filter-list-title-base' => 'elements/filter-list/filter-list-title-base.css',
  'lqdsep-filter-list-title-lg' => 'elements/filter-list/filter-list-title-lg.css',
  'lqdsep-filter-list-title-md' => 'elements/filter-list/filter-list-title-md.css',
  'lqdsep-filter-list-title-sm' => 'elements/filter-list/filter-list-title-sm.css',
  'lqdsep-filter-list-title-xl' => 'elements/filter-list/filter-list-title-xl.css',
  'lqdsep-filter-list-title-xxl' => 'elements/filter-list/filter-list-title-xxl.css',
  'lqdsep-filter-list-underline-alt' => 'elements/filter-list/filter-list-underline-alt.css',
  'lqdsep-filter-list-underline' => 'elements/filter-list/filter-list-underline.css',
);