<?php
 $header_dropdown = array(
  'lqdsep-header-dropdown-base' => 'header/modules/module-dropdown-base.css',
);