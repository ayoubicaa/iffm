<?php

$section = array(
  'lqdsep-sticky-section' => 'elements/sticky/sticky-section.css',
  'lqdsep-svg-divider-base' => 'theme-features/svg-dividers.css',
  'lqdsep-section-scroll-base' => 'theme-features/section-scroll.css',
  'lqdsep-header-stickybar-base' => 'header/stickybar/stickybar-base.css',
  'lqdsep-header-stickybar-left' => 'header/stickybar/stickybar-left.css',
  'lqdsep-header-stickybar-right' => 'header/stickybar/stickybar-right.css',
);