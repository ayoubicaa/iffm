<?php
$progressbar = array(
    'lqdsep-progressbar-base' => 'elements/progressbar/progressbar-base.css',
    'lqdsep-progressbar-values-inline' => 'elements/progressbar/progressbar-values-inline.css',
);