<?php
$team_member = array(
    'lqdsep-team-member-base' => 'elements/team-member/team-member-base.css',
);
for ( $i = 1; $i <= 6; $i++ ) {
    $tab['lqdsep-team-member-style-' . $i] = 'elements/team-member/team-member-style-' . $i . '.css';
}