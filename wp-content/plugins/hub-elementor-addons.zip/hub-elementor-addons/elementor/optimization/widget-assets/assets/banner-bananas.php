<?php
 $banner_bananas = array(
    'lqdsep-banner-bananas-base' => 'elements/banner-bananas/banner-bananas-base.css',
);