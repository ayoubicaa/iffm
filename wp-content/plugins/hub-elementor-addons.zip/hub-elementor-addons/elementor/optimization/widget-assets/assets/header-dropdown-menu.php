<?php
 $header_dropdown_menu = array(
  'lqdsep-header-dropdown-menu-base' => 'header/modules/module-dropdown-menu.css',
);