<?php
 $animated_frame = array(
    'lqdsep-animated-frame-base' => 'elements/animated-frame/animated-frame-base.css',
    'lqdsep-animated-frame-nav' => 'elements/animated-frame/animated-frame-nav.css',
    'lqdsep-animated-frame-num' => 'elements/animated-frame/animated-frame-num.css',
);