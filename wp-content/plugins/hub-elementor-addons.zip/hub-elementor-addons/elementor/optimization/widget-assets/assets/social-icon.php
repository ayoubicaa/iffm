<?php

$social_icon = array(
  'lqdsep-social-icon-base' => 'elements/social-icon/social-icon-base.css',
  'lqdsep-social-icon-sm' => 'elements/social-icon/social-icon-sm.css',
  'lqdsep-social-icon-md' => 'elements/social-icon/social-icon-md.css',
  'lqdsep-social-icon-lg' => 'elements/social-icon/social-icon-lg.css',
  'lqdsep-social-icon-vertical' => 'elements/social-icon/social-icon-vertical.css',
);