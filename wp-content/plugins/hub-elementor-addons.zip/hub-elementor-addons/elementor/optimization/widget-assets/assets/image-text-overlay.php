<?php
 $image_text_overlay = array(
    'lqdsep-image-overlay-text' => 'elements/image-overlay-text/image-overlay-text.css',
);