<?php
 $particles = array(
    'lqdsep-particles-base' => 'elements/particles/particles-base.css',
    'lqdsep-particles-visible-onhover' => 'elements/particles/particles-visible-onhover.css',
);