<?php
 $masked_image = array(
    'lqdsep-masked-image-base' => 'elements/masked-image/masked-image-base.css',
);