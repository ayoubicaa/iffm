<?php
$split_text = array(
  'lqdsep-split-text-base' => 'elements/split-text/split-text-base.css',
  'lqdsep-split-text-char' => 'elements/split-text/split-text-char.css',
  'lqdsep-split-text-word' => 'elements/split-text/split-text-word.css',
  'lqdsep-split-text-line' => 'elements/split-text/split-text-line.css',
);