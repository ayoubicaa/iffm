<?php
 $promo = array(
    'lqdsep-promo-base' => 'elements/promo/promo-base.css',
);