<?php
 $typewriter = array(
    'lqdsep-typewriter-base' => 'elements/typewriter/typewriter-base.css',
);