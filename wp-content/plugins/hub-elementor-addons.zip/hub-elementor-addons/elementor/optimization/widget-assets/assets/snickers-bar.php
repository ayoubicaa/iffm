<?php
 $snickers_bar = array(
    'lqdsep-snickers-bar-base' => 'elements/snickers-bar/snickers-bar.css',
);