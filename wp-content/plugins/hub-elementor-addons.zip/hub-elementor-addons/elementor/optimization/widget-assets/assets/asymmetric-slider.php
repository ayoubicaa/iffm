<?php
 $asymmetric_slider = array(
    'lqdsep-asymmetric-slider-base' => 'elements/asymmetric-slider/asymmetric-slider-base.css',
);