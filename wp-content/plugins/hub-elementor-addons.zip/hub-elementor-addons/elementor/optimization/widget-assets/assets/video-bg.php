<?php
 $video_bg = array(
    'lqdsep-video-bg-base' => 'elements/video-bg/video-bg-base.css',
);