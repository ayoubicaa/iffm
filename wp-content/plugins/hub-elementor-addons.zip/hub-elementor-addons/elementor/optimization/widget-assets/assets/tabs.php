<?php

$tab = array(
    'lqdsep-tab-base' => 'elements/tab/tab-base.css',
    'lqdsep-tab-arrows' => 'elements/tab/tab-arrows.css',
    'lqdsep-tab-nav-base' => 'elements/tab/tab-nav-base.css',
    'lqdsep-tab-nav-has-btn' => 'elements/tab/tab-nav-has-btn.css',
    'lqdsep-tab-nav-icon-inline' => 'elements/tab/tab-nav-icon-inline.css',
    'lqdsep-tab-nav-iconbox' => 'elements/tab/tab-nav-iconbox.css',
    'lqdsep-tab-nav-not-expanded' => 'elements/tab/tab-nav-not-expanded.css',
    'lqdsep-tab-nav-plain' => 'elements/tab/tab-nav-plain.css',
);
for ( $i = 1; $i <= 14; $i++ ) {
    $tab['lqdsep-tab-style-' . $i] = 'elements/tab/tab-style-' . $i . '.css';
    if ( $i === 9 ) {
        $tab['lqdsep-tab-style-' . $i . '-alt'] = 'elements/tab/tab-style-' . $i . '-alt.css';
        $tab['lqdsep-tab-style-' . $i . '-alt-2'] = 'elements/tab/tab-style-' . $i . '-alt-2.css';
    }
}
