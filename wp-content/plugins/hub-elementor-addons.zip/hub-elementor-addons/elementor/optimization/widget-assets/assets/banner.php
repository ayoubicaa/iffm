<?php
 $banner = array(
    'lqdsep-banner-base' => 'elements/banner/banner-base.css',
);