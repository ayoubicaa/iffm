<?php
 $vertical_slider = array(
    'lqdsep-vertical-slider-base' => 'elements/vertical-slider/vertical-slider-base.css',
);