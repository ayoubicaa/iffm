<?php
$page_blocks = array(
  'lqdsep-page-blocks-base' => 'page-layouts/page-blocks/page-blocks-base.css',
  'lqdsep-page-blocks-effect-fadeScale' => 'page-layouts/page-blocks/page-blocks-effect-fadeScale.css',
  'lqdsep-page-blocks-effect-mask' => 'page-layouts/page-blocks/page-blocks-effect-mask.css',
  'lqdsep-page-blocks-effect-slideOver' => 'page-layouts/page-blocks/page-blocks-effect-slideOver.css',
  'lqdsep-page-blocks-nav-base' => 'page-layouts/page-blocks/page-blocks-nav-base.css',
  'lqdsep-page-blocks-nav-style-1' => 'page-layouts/page-blocks/page-blocks-nav-style-1.css',
  'lqdsep-page-blocks-nav-style-2' => 'page-layouts/page-blocks/page-blocks-nav-style-2.css',
  'lqdsep-page-blocks-nav-style-3' => 'page-layouts/page-blocks/page-blocks-nav-style-3.css',
  'lqdsep-page-blocks-nav-style-4' => 'page-layouts/page-blocks/page-blocks-nav-style-4.css',
  'lqdsep-page-blocks-numbers-base' => 'page-layouts/page-blocks/page-blocks-numbers-base.css',
  'lqdsep-page-blocks-numbers-style-1' => 'page-layouts/page-blocks/page-blocks-numbers-style-1.css',
  'lqdsep-page-blocks-numbers-style-2' => 'page-layouts/page-blocks/page-blocks-numbers-style-2.css',
  'lqdsep-page-blocks-prevnext-base' => 'page-layouts/page-blocks/page-blocks-prevnext-base.css',
  'lqdsep-page-blocks-prevnext-style-1' => 'page-layouts/page-blocks/page-blocks-prevnext-style-1.css',
  'lqdsep-page-blocks-prevnext-style-2' => 'page-layouts/page-blocks/page-blocks-prevnext-style-2.css',
);