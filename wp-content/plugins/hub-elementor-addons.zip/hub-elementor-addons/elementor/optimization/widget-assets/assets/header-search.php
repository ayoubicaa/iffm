<?php
$header_search = array(
  'lqdsep-header-search-base' => 'header/modules/module-search-base.css',
  'lqdsep-header-search-style-default' => 'header/modules/module-search-style-default.css',
  'lqdsep-header-search-style-frame' => 'header/modules/module-search-style-frame.css',
  'lqdsep-header-search-style-slide' => 'header/modules/module-search-style-slide-top.css',
  'lqdsep-header-search-style-zoom' => 'header/modules/module-search-style-zoom-out.css',
);