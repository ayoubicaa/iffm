<?php
 $header_logo = array(
    'lqdsep-header-logo-base' => 'header/modules/module-logo.css',
    'lqdsep-header-logo-solid' => 'header/modules/module-logo-solid.css',
    'lqdsep-header-logo-hover-image' => 'header/modules/module-logo-hover-image.css',
);