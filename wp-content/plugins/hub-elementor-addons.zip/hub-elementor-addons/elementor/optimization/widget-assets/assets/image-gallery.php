<?php
 $image_gallery = array(
    'lqdsep-image-gallery-base' => 'elements/image-gallery/image-gallery-base.css',
);