<?php

$lightbox = array(
  'lqdsep-lightbox-base' => 'elements/lightbox/lightbox-base.css',
);