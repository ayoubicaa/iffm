<?php
 $iconbox_circle = array(
    'lqdsep-icon-box-circle-base' => 'elements/icon-box-circle/iconbox-circle-base.css',
);