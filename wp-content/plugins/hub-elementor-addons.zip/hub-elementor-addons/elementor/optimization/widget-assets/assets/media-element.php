<?php
 $media_element = array(
    'lqdsep-media-element-base' => 'elements/media-element/media-element-base.css',
    'lqdsep-media-element-contents-visible' => 'elements/media-element/media-element-contents-visible.css',
    'lqdsep-media-element-icon' => 'elements/media-element/media-element-icon.css',
    'lqdsep-media-element-shadow-onhover' => 'elements/media-element/media-element-shadow-onhover.css',
);