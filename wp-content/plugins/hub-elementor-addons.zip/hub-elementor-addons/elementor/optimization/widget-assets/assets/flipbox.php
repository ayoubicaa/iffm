<?php
 $flipbox = array(
    'lqdsep-flipbox-base' => 'elements/flipbox/flipbox-base.css',
    'lqdsep-flipbox-bt' => 'elements/flipbox/flipbox-bt.css',
    'lqdsep-flipbox-rl' => 'elements/flipbox/flipbox-rl.css',
    'lqdsep-flipbox-shadow-bt' => 'elements/flipbox/flipbox-shadow-bt.css',
    'lqdsep-flipbox-shadow-onhover' => 'elements/flipbox/flipbox-shadow-onhover.css',
    'lqdsep-flipbox-shadow-onhover-bt' => 'elements/flipbox/flipbox-shadow-onhover-bt.css',
    'lqdsep-flipbox-shadow-onhover-tb' => 'elements/flipbox/flipbox-shadow-onhover-tb.css',
    'lqdsep-flipbox-shadow-tb' => 'elements/flipbox/flipbox-shadow-tb.css',
    'lqdsep-flipbox-shadow' => 'elements/flipbox/flipbox-shadow.css',
    'lqdsep-flipbox-tb' => 'elements/flipbox/flipbox-tb.css',
);