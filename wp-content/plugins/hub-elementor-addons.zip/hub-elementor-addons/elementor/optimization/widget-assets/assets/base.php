<?php

$base = array(
  'lqdsep-base' => 'base/base.css',
  'lqdsep-base-typography' => 'base/typography.css',
);