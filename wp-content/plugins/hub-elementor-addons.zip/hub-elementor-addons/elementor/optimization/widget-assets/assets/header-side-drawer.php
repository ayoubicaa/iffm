<?php
 $header_side_drawer = array(
    'lqdsep-header-side-drawer-base' => 'header/modules/module-sidedrawer.css',
);