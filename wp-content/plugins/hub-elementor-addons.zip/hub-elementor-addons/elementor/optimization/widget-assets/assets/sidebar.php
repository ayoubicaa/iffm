<?php
$sidebar = array(
  'lqdsep-sidebar-base' => 'sidebar/sidebar-base.css',
);