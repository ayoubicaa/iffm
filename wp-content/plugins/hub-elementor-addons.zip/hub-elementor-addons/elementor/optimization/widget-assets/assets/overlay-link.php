<?php
 $overlay_link = array(
    'lqdsep-overlay-link-base' => 'elements/overlay-link/overlay-link.css',
);