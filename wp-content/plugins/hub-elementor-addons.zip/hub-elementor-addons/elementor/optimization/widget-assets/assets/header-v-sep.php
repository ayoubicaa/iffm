<?php
 $header_v_sep = array(
    'lqdsep-header-v-sep-base' => 'header/modules/module-v-sep.css',
);