<?php
 $image_comparison = array(
    'lqdsep-image-comparison-base' => 'elements/image-comparison/image-comparison-base.css',
);