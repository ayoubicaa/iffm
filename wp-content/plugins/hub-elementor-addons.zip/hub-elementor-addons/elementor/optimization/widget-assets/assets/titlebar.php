<?php
 $titlebar = array(
    'lqdsep-titlebar-base' => 'titlebar/titlebar-base.css'
);