<?php
 $image_text_slider = array(
    'lqdsep-image-text-slider-base' => 'elements/image-text-slider/image-text-slider-base.css',
);