<?php
 $header_fullscreen_nav = array(
    'lqdsep-header-fullscreen-nav-base' => 'header/modules/module-fullscreen-nav.css',
);