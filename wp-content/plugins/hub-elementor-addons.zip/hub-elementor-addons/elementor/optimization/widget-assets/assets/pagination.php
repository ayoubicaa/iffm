<?php
 $pagination = array(
    'lqdsep-pagination-base' => 'elements/pagination/pagination-base.css',
);