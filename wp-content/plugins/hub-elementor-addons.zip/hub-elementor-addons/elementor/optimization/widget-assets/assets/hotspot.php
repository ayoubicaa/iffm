<?php
 $hotspot = array(
    'lqdsep-hotspot-base' => 'elements/hotspot/hotspot-base.css',
    'lqdsep-hotspot-item-x' => 'elements/hotspot/hotspot-item-x.css',
    'lqdsep-hotspot-item-y' => 'elements/hotspot/hotspot-item-y.css',
    'lqdsep-hotspot-item-t' => 'elements/hotspot/hotspot-item-t.css',
    'lqdsep-hotspot-item-r' => 'elements/hotspot/hotspot-item-r.css',
    'lqdsep-hotspot-item-b' => 'elements/hotspot/hotspot-item-b.css',
    'lqdsep-hotspot-item-l' => 'elements/hotspot/hotspot-item-l.css',
);