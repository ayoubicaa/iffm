<?php
$portfolio_single_meta = array(
  'lqdsep-pf-single-meta-cover' => 'portfolio/portfolio-single-meta/pf-cover.css',
  'lqdsep-pf-single-meta-meta' => 'portfolio/portfolio-single-meta/pf-meta.css',
  'lqdsep-pf-single-meta-nav' => 'portfolio/portfolio-single-meta/pf-nav.css',
  'lqdsep-pf-single-meta-related-projects' => 'portfolio/portfolio-single-meta/pf-related-projects.css',
  'lqdsep-pf-single-meta-scroll-down-link' => 'portfolio/portfolio-single-meta/pf-scroll-down-link.css',
  'lqdsep-pf-single-meta-title' => 'portfolio/portfolio-single-meta/pf-title.css',
);