<?php
 $custom_animations = array(
    'lqdsep-custom-animations' => 'theme-features/custom-animations.css',
 );
