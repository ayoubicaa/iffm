<?php
 $carousel_stack = array(
    'lqdsep-carousel-stack-base' => 'elements/carousel-stack/carousel-stack-base.css',
);