<?php

$column = array(
  'lqdsep-sticky-column' => 'elements/sticky/sticky-column.css',
);