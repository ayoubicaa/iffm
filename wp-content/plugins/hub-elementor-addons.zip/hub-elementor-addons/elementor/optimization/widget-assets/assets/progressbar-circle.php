<?php
$progressbar_circle = array(
    'lqdsep-progressbar-circle-base' => 'elements/progressbar/progressbar-circle.css',
);