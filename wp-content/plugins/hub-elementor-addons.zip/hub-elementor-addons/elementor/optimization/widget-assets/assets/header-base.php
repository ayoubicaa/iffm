<?php
$header_base = array(
  'lqdsep-header-base' => 'header/header-base.css',
  'lqdsep-header-overlay' => 'header/header-overlay.css',
  'lqdsep-header-sticky' => 'header/header-sticky.css',
  'lqdsep-header-sticky-hide-onstuck' => 'header/header-sticky-hide-onstuck.css',
  'lqdsep-header-sticky-show-onstuck' => 'header/header-sticky-show-onstuck.css',
  'lqdsep-header-sticky-no-shadow' => 'header/header-sticky-no-shadow.css',
  'lqdsep-header-mobile-menu-base' => 'header/mobile-section/mobile-section-base.css',
  'lqdsep-header-megamenu-slide-base' => 'header/megamenu/megamenu-slide.css',
);