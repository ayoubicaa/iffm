<?php
$header_module_trigger = array(
  'lqdsep-header-module-trigger-base' => 'header/modules/module-trigger.css',
);