<?php
 $milestone = array(
  'lqdsep-milestone-base' => 'elements/milestone/milestone-base.css',
);