<?php
 $header_cart = array(
    'lqdsep-header-cart-base' => 'header/modules/module-cart.css',
    'lqdsep-header-cart-offcanvas' => 'header/modules/module-cart-offcanvas.css',
);