<?php
 $interactive_text_image = array(
    'lqdsep-interactive-text-image-base' => 'elements/interactive-text-image/interactive-text-image.css',
);