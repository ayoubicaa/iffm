<?php
$footer_base = array(
  'lqdsep-footer-sticky' => 'footer/sticky-footer.css',
);