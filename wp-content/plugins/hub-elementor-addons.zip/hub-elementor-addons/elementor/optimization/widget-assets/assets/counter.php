<?php
 $counter = array(
    'lqdsep-counter-base' => 'elements/counter/counter-base.css',
    'lqdsep-counter-bordered' => 'elements/counter/counter-bordered.css',
    'lqdsep-counter-icon' => 'elements/counter/counter-icon.css',
    'lqdsep-counter-overlay-bg' => 'elements/counter/counter-overlay-bg.css',
    'lqdsep-counter-solid' => 'elements/counter/counter-solid.css',
);