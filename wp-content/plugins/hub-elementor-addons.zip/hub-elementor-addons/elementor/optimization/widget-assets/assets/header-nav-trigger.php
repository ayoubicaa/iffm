<?php
$header_nav_trigger = array(
  'lqdsep-header-nav-trigger-base' => 'header/modules/module-nav-trigger-base.css',
  'lqdsep-header-nav-trigger-style-1' => 'header/modules/module-nav-trigger-style-1.css',
  'lqdsep-header-nav-trigger-style-2' => 'header/modules/module-nav-trigger-style-2.css',
  'lqdsep-header-nav-trigger-style-3' => 'header/modules/module-nav-trigger-style-3.css',
  'lqdsep-header-nav-trigger-style-4' => 'header/modules/module-nav-trigger-style-4.css',
  'lqdsep-header-nav-trigger-style-5' => 'header/modules/module-nav-trigger-style-5.css',
  'lqdsep-header-nav-trigger-style-6' => 'header/modules/module-nav-trigger-style-6.css',
);