﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'lt', {
	button: 'Įdėti kaip gryną tekstą',
	title: 'Įdėti kaip gryną tekstą'
} );
