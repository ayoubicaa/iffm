<?php 

extract( $atts );

?>
<div class="header-module <?php echo $el_class ?>">
	<?php $this->get_menu() ?>
</div>