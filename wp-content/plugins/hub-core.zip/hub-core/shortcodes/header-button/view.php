<?php 

extract( $atts );

$this->generate_css();
?>
<div class="header-module module-button">
	<?php $this->get_button() ?>
</div>